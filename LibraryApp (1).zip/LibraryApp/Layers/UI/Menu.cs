using LibraryApp.Models;
using LibraryApp.Services;

namespace LibraryApp.UI
{
    // This layer only shows menus and takes input from the user.
    // The real work is done by the service.
    public class Menu
    {
        private LibraryService service = new LibraryService();

        public void MainMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("-----------------------------------------");
                Console.WriteLine("---------LIBRARY MANAGEMENT SYSTEM-------");
                Console.WriteLine("-----------------------------------------");
                Console.WriteLine("1. Admin");
                Console.WriteLine("2. User");
                Console.WriteLine("0. Exit");

                int choice = ReadNumber("Enter main choice: ");

                if (choice == 0)
                {
                    break;
                }
                else if (choice == 1)
                {
                    AdminMenu();
                }
                else if (choice == 2)
                {
                    UserMenu();
                }
            }
        }

        private void AdminMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("\n--- ADMIN MENU ---");
                Console.WriteLine("1. Add Book");
                Console.WriteLine("2. Show Books");
                Console.WriteLine("3. Update Copies");
                Console.WriteLine("4. Search Book");
                Console.WriteLine("5. Sort Books");
                Console.WriteLine("6. View Issue History");
                Console.WriteLine("7. Delete Book");
                Console.WriteLine("0. Back");

                int choice = ReadNumber("Enter choice: ");

                if (choice == 0)
                {
                    break;
                }

                if (choice == 1) AddBook();
                else if (choice == 2) ShowBooks();
                else if (choice == 3) UpdateCopies();
                else if (choice == 4) SearchBook();
                else if (choice == 5) SortBooks();
                else if (choice == 6) ShowIssueHistory();
                else if (choice == 7) DeleteBook();

                Console.WriteLine("\nPress any key to continue");
                Console.ReadKey();
            }
        }

        private void UserMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("\n--- USER MENU ---");
                Console.WriteLine("1. View Books");
                Console.WriteLine("2. Borrow Book");
                Console.WriteLine("3. Return Book");
                Console.WriteLine("4. Search Book");
                Console.WriteLine("5. View Issue History");
                Console.WriteLine("0. Back");

                int choice = ReadNumber("Enter user choice: ");

                if (choice == 0)
                {
                    break;
                }

                if (choice == 1) ShowBooks();
                else if (choice == 2) BorrowBook();
                else if (choice == 3) ReturnBook();
                else if (choice == 4) SearchBook();
                else if (choice == 5) ShowIssueHistory();

                Console.WriteLine("\nPress any key to continue");
                Console.ReadKey();
            }
        }

        // ---------- functions used by the menus ----------

        private void AddBook()
        {
            Console.Write("Enter book name: ");
            string name = Console.ReadLine();

            Console.Write("Enter author name: ");
            string author = Console.ReadLine();

            int copies = ReadNumber("Enter number of copies: ");

            Console.WriteLine(service.AddBook(name, author, copies));
        }

        private void ShowBooks()
        {
            List<Book> books = service.GetBooks();

            if (books.Count == 0)
            {
                Console.WriteLine("No books available!");
                return;
            }

            Console.WriteLine("\n--- BOOK LIST ---");

            for (int i = 0; i < books.Count; i++)
            {
                Console.WriteLine(i + ". " + books[i].Name +
                                  " | Author: " + books[i].Author +
                                  " | Copies: " + books[i].Copies);
            }
        }

        private void UpdateCopies()
        {
            int index = ReadNumber("Enter book index: ");
            int add = ReadNumber("Enter copies to add: ");

            Console.WriteLine(service.UpdateCopies(index, add));
        }

        private void SearchBook()
        {
            if (service.GetBooks().Count == 0)
            {
                Console.WriteLine("No books available!");
                return;
            }

            Console.Write("Enter book name: ");
            string name = Console.ReadLine();

            List<Book> found = service.SearchBook(name);

            if (found.Count == 0)
            {
                Console.WriteLine("Book not found!");
                return;
            }

            foreach (Book book in found)
            {
                Console.WriteLine("Found: " + book.Name +
                                  " | Author: " + book.Author +
                                  " | Copies: " + book.Copies);
            }
        }

        private void SortBooks()
        {
            service.SortBooks();
            Console.WriteLine("Books sorted successfully!");
            ShowBooks();
        }

        private void DeleteBook()
        {
            if (service.GetBooks().Count == 0)
            {
                Console.WriteLine("No books available!");
                return;
            }

            ShowBooks();
            int index = ReadNumber("\nEnter book index to delete: ");

            Console.WriteLine(service.DeleteBook(index));
        }

        private void BorrowBook()
        {
            if (service.GetBooks().Count == 0)
            {
                Console.WriteLine("No books available!");
                return;
            }

            int index = ReadNumber("Enter book index: ");

            Console.WriteLine(service.BorrowBook(index));
        }

        private void ReturnBook()
        {
            int index = ReadNumber("Enter book index: ");

            Console.WriteLine(service.ReturnBook(index));
        }

        private void ShowIssueHistory()
        {
            List<string> history = service.GetIssueHistory();

            if (history.Count == 0)
            {
                Console.WriteLine("No books issued yet!");
                return;
            }

            Console.WriteLine("\n--- ISSUE HISTORY ---");

            for (int i = 0; i < history.Count; i++)
            {
                Console.WriteLine((i + 1) + ". " + history[i]);
            }
        }

        // keeps asking until the user types a proper number
        private int ReadNumber(string message)
        {
            int number;

            Console.Write(message);

            while (!int.TryParse(Console.ReadLine(), out number))
            {
                Console.Write("Please enter a number: ");
            }

            return number;
        }
    }
}
