using LibraryApp.Models;

namespace LibraryApp.Repository
{
    // This layer only talks to the file (books.txt).
    // No menus and no rules here, just reading and saving.
    public class BookRepository
    {
        private string filePath = "books.txt";

        // read all books from the file
        public List<Book> LoadBooks()
        {
            List<Book> books = new List<Book>();

            if (!File.Exists(filePath))
            {
                return books;
            }

            string[] lines = File.ReadAllLines(filePath);

            foreach (string line in lines)
            {
                // each line looks like:  name,author,copies
                string[] parts = line.Split(',');

                if (parts.Length == 3)
                {
                    Book book = new Book();
                    book.Name = parts[0];
                    book.Author = parts[1];
                    book.Copies = int.Parse(parts[2]);
                    books.Add(book);
                }
            }

            return books;
        }

        // write all books to the file
        public void SaveBooks(List<Book> books)
        {
            List<string> lines = new List<string>();

            foreach (Book book in books)
            {
                lines.Add(book.Name + "," + book.Author + "," + book.Copies);
            }

            File.WriteAllLines(filePath, lines);
        }
    }
}
