namespace LibraryApp.Models
{
    // This class just holds the data of one book
    public class Book
    {
        public string Name { get; set; }
        public string Author { get; set; }
        public int Copies { get; set; }
    }
}
