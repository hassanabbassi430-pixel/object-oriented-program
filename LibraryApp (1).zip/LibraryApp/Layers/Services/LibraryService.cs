using LibraryApp.Models;
using LibraryApp.Repository;

namespace LibraryApp.Services
{
    // All the rules of the library are here (checking, adding, borrowing...).
    // It uses the repository to save data and gives a message back to the UI.
    public class LibraryService
    {
        private BookRepository repository = new BookRepository();
        private List<Book> books;
        private List<string> issuedBooks = new List<string>();

        private int maxBooks = 20;

        public LibraryService()
        {
            books = repository.LoadBooks();
        }

        public List<Book> GetBooks()
        {
            return books;
        }

        public List<string> GetIssueHistory()
        {
            return issuedBooks;
        }

        public string AddBook(string name, string author, int copies)
        {
            if (books.Count >= maxBooks)
            {
                return "Library is full!";
            }

            if (name.Trim() == "")
            {
                return "Invalid book name!";
            }

            if (author.Trim() == "")
            {
                return "Invalid author name!";
            }

            if (copies <= 0)
            {
                return "Copies must be greater than 0!";
            }

            Book book = new Book();
            book.Name = name.Trim();
            book.Author = author.Trim();
            book.Copies = copies;

            books.Add(book);
            repository.SaveBooks(books);

            return "Book added successfully!";
        }

        public string UpdateCopies(int index, int add)
        {
            if (index < 0 || index >= books.Count)
            {
                return "Invalid index!";
            }

            if (books[index].Copies + add < 0)
            {
                return "Copies cannot be less than 0!";
            }

            books[index].Copies += add;
            repository.SaveBooks(books);

            return "Copies updated!";
        }

        public List<Book> SearchBook(string name)
        {
            List<Book> found = new List<Book>();

            foreach (Book book in books)
            {
                if (book.Name.ToLower() == name.Trim().ToLower())
                {
                    found.Add(book);
                }
            }

            return found;
        }

        public void SortBooks()
        {
            books = books.OrderBy(b => b.Name).ToList();
            repository.SaveBooks(books);
        }

        public string DeleteBook(int index)
        {
            if (index < 0 || index >= books.Count)
            {
                return "Invalid index!";
            }

            books.RemoveAt(index);
            repository.SaveBooks(books);

            return "Book deleted successfully!";
        }

        public string BorrowBook(int index)
        {
            if (index < 0 || index >= books.Count)
            {
                return "Invalid index!";
            }

            if (books[index].Copies == 0)
            {
                return "Book not available!";
            }

            books[index].Copies--;
            issuedBooks.Add(books[index].Name);
            repository.SaveBooks(books);

            return "Book issued successfully!";
        }

        public string ReturnBook(int index)
        {
            if (index < 0 || index >= books.Count)
            {
                return "Invalid index!";
            }

            books[index].Copies++;
            repository.SaveBooks(books);

            return "Book returned successfully!";
        }
    }
}
