using LibraryApp.UI;

namespace LibraryApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu menu = new Menu();
            menu.MainMenu();
        }
    }
}
